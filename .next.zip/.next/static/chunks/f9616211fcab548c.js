__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/32c3dc9038c6a313.js",
  "static/chunks/turbopack-c25269367be5fdd5.js"
])
