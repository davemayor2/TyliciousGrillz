__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/32c3dc9038c6a313.js",
  "static/chunks/turbopack-a1e79493218711e4.js"
])
