var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/checkout/route.js")
R.c("server/chunks/[root-of-the-server]__c38e89b9._.js")
R.c("server/chunks/[root-of-the-server]__35b7515f._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(42000)
R.m(63437)
module.exports=R.m(63437).exports
