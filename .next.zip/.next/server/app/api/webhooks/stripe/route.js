var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhooks/stripe/route.js")
R.c("server/chunks/[root-of-the-server]__84835872._.js")
R.c("server/chunks/[root-of-the-server]__35b7515f._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(1478)
R.m(33009)
module.exports=R.m(33009).exports
