globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/32c3dc9038c6a313.js",
      "static/chunks/turbopack-c25269367be5fdd5.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/32c3dc9038c6a313.js",
      "static/chunks/turbopack-a1e79493218711e4.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c85a7d07e7b82c9a.js",
    "static/chunks/ae0b2d48db50b14d.js",
    "static/chunks/bae01d964e8808cf.js",
    "static/chunks/66e5d5d1b426d5e4.js",
    "static/chunks/turbopack-416f88faa73463c8.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];